输入help查看帮助
panpan's shell a new shell